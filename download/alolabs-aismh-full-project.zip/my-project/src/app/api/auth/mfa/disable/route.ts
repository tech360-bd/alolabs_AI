import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Find the user
    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    if (!user.otpEnabled) {
      return NextResponse.json(
        { error: 'MFA is not currently enabled for this user.' },
        { status: 400 }
      );
    }

    // Disable MFA: clear secret and set enabled to false
    await db.user.update({
      where: { id: userId },
      data: {
        otpEnabled: false,
        otpSecret: null,
      },
    });

    // Remove backup codes from Settings
    try {
      await db.settings.delete({
        where: { key: `mfa_backup:${userId}` },
      });
    } catch {
      // Backup codes setting may not exist
    }

    return NextResponse.json({
      message: 'MFA disabled successfully',
      enabled: false,
    });
  } catch (error) {
    console.error('MFA disable error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}